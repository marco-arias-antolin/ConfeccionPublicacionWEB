var opciones = "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=700,height=700,top=66,left=166";
window.open('pop.html', '', opciones);
